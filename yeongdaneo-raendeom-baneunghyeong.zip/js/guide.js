// 가이드
function reference() {
  alert('enter: 정답확인\nCtrl: 다음 문제\nDelete: 해당 내용 제외');
}