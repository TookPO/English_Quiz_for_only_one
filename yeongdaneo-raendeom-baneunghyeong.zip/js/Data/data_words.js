var words = [
  // 수업 2024-05-02
  { question: "Acquaintance", answer: "지인" },
  { question: "Exaggerate", answer: "과장하다" },
  { question: "Colleague", answer: "동료" },

  // 2024-05-04
  { question: "meet", answer: "맞추다, 충족시키다" },
  { question: "indicate", answer: "~을 나타내다, (간단히) 말하다" },

  // 2024-05-06[600 RC 부교재]
  { question: "come up", answer: "생기다, 나타나다, 떠오르다" },
  { question: "component", answer: "구성하는, 구성 요소" },
  { question: "regulation", answer: "규칙, 규정의, 보통의" },
  { question: "implement", answer: "도구, 기구, 수단, ~에게 필요한 권한을 주다." },
  { question: "aim", answer: "목표, 의도, 겨누다" },
  { question: "inspection", answer: "정밀 검사, 점검" },
  { question: "anticipate", answer: "예상하다, 기대하다" },
  { question: "loss", answer: "분실, 손실, 감소" },
  { question: "lose", answer: "잃다, 지다" },
  { question: "voucher", answer: "보증인, 증명하다" },
  { question: "occasion", answer: "경우, 행사, ~의 원인이 되다" },
  { question: "composer", answer: "작곡가" },
  { question: "compose", answer: "조립하다, 구성하다, 작곡하다" },
  { question: "guidance", answer: "안내, 지시" },
  { question: "certification", answer: "증명, 증명서" },
  { question: "a number of", answer: "많은" },
  { question: "the number of", answer: "~의 수" },

  // 2024-05-06
  { question: "upon", answer: "=on" },

  // 2024-05-08
  { question: "(be) in charge of", answer: "~을 책임지다" },

  // 2024-05-21
  { question: "department", answer: "부서" },
  { question: "aunt", answer: "아주머니, 외숙모" },

  // { question: "on의 5가지 의미는?", answer: "접촉, 계속의, 시간, 장소, 관하여" },

  // { question: "", answer: "" },

];