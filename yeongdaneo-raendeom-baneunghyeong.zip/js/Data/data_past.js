var past = [
  /*   { question: "awake(깨다)", answer: "awoke" },
    { question: "beat(때리다)", answer: "beat" },
    { question: "become(~이 되다.)", answer: "became" },
    { question: "begin", answer: "began" },
    { question: "bite", answer: "bit" },
    { question: "blow", answer: "blew" },
    { question: "bring", answer: "brought" },
    { question: "build", answer: "built" },
    { question: "burn", answer: "burned/burnt" },
    { question: "buy", answer: "bought" },
    { question: "catch", answer: "caught" },
    { question: "choose", answer: "chose" },
    { question: "deal", answer: "dealt" },
    { question: "drink", answer: "drank" },
    { question: "drive", answer: "drove" },
    { question: "fall", answer: "fell" },
    { question: "fight", answer: "fought" },
    { question: "find", answer: "found" },
    { question: "fly", answer: "flew" },
    { question: "forbid(금지하다)", answer: "forbad/forbade" },
    { question: "rode", answer: "ride" }, */

  // [1일차 RC]




  // { question: "", answer: "" },

];